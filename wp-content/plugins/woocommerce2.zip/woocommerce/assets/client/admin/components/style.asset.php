<?php return array('version' => 'd2d6558096bd043ac317');
