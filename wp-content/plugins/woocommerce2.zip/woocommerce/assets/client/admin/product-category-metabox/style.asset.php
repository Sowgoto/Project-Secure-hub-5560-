<?php return array('version' => '00c30068d576cf41bc5b');
