<?php return array('version' => '8f78973dc9c3ad429f01');
