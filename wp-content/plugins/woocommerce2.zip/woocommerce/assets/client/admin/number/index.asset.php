<?php return array('dependencies' => array(), 'version' => 'c30720e5ebdf9cb16d10');
