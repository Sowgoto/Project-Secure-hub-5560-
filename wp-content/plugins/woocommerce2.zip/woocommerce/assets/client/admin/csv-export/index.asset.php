<?php return array('dependencies' => array(), 'version' => 'f884e772de8de6343f08');
